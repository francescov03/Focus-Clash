//
//  MarigoldApp2App.swift
//  MarigoldApp2
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

@main
struct MarigoldApp2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

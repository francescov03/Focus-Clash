//
//  GameCenterService.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import GameKit
import Observation
import UIKit

@Observable
final class GameCenterService {

    static let shared = GameCenterService()

    private(set) var isAuthenticated = false
    private(set) var displayName: String?
    private(set) var avatarImage: UIImage?
    private(set) var requiresSettings = false   // ⬅️ NUOVO

    private init() {}

    func authenticate() {
        requiresSettings = false

        GKLocalPlayer.local.authenticateHandler = { viewController, error in

            if let viewController {
                UIApplication.shared
                    .connectedScenes
                    .compactMap { $0 as? UIWindowScene }
                    .first?
                    .keyWindow?
                    .rootViewController?
                    .present(viewController, animated: true)
                return
            }

            if GKLocalPlayer.local.isAuthenticated {
                self.isAuthenticated = true
                self.displayName = GKLocalPlayer.local.displayName
                self.loadAvatar()
            } else {
                self.isAuthenticated = false
                self.displayName = nil
                self.avatarImage = nil
                self.requiresSettings = true   // ⬅️ Game Center OFF
            }
        }
    }

    private func loadAvatar() {
        GKLocalPlayer.local.loadPhoto(for: .normal) { image, _ in
            DispatchQueue.main.async {
                self.avatarImage = image
            }
        }
    }
}

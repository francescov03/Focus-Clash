//
//  ConfettiView.swift
//  FocusClash
//
//  Created by Foundation 44 on 03/02/26.
//

import SwiftUI

struct ConfettiView: View {

    @State private var particles: [ConfettiParticle] = []

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ForEach(particles) { particle in
                    Circle()
                        .fill(particle.color)
                        .frame(width: particle.size, height: particle.size)
                        .position(particle.position)
                        .opacity(particle.opacity)
                }
            }
            .onAppear {
                let screen = geo.size
                particles = (0..<40).map { _ in
                    ConfettiParticle(screenSize: screen)
                }
            }
        }
    }
}

// MARK: - Particle model
struct ConfettiParticle: Identifiable {

    let id = UUID()
    let color: Color
    let size: CGFloat
    var position: CGPoint
    let opacity: Double

    init(screenSize: CGSize) {
        color = [.red, .blue, .green, .yellow, .purple, .mint].randomElement()!
        size = CGFloat.random(in: 6...12)
        position = CGPoint(
            x: CGFloat.random(in: 0...screenSize.width),
            y: CGFloat.random(in: 0...screenSize.height)
        )
        opacity = Double.random(in: 0.6...1)
    }
}

//
//  InfoSheetView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

struct InfoSheetView: View {

    let viewModel: TimerViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    VStack(alignment: .leading, spacing: 8) {
                        Label("How points work", systemImage: "sparkles")
                            .font(.title2)
                            .bold()

                        Text("Points are rewarded for time spent focusing.")
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    // ✅ Rule card
                    InfoCard(
                        title: "Rule",
                        subtitle: "Every 5 minutes of focus = 1 point",
                        systemImage: "timer"
                    )

                    // ✅ Examples card
                    VStack(alignment: .leading, spacing: 12) {
                        Label("Examples", systemImage: "list.bullet.rectangle")
                            .font(.headline)

                        VStack(spacing: 10) {
                            ExampleRow(minutes: 5)
                            ExampleRow(minutes: 10)
                            ExampleRow(minutes: 15)
                            ExampleRow(minutes: 25)
                            ExampleRow(minutes: 60)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 18))

                    // ✅ Your points card
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Your progress", systemImage: "person.crop.circle")
                            .font(.headline)

                        HStack {
                            Text("Total points")
                                .foregroundStyle(.secondary)
                            Spacer()
                            Text("\(viewModel.points)")
                                .font(.title3)
                                .bold()
                                .contentTransition(.numericText())
                                .animation(.spring(response: 0.35, dampingFraction: 0.85), value: viewModel.points)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                }
                .padding()
            }
            .navigationTitle("Points")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

private struct InfoCard: View {
    let title: String
    let subtitle: String
    let systemImage: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(title, systemImage: systemImage)
                .font(.headline)

            Text(subtitle)
                .font(.title3)
                .bold()
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

private struct ExampleRow: View {
    let minutes: Int
    private var points: Int { max(1, minutes / 5) }

    var body: some View {
        HStack {
            Text("\(minutes) min")
                .font(.headline)

            Spacer()

            Text("\(points) pt\(points == 1 ? "" : "s")")
                .font(.headline)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 12)
        .background(.black.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

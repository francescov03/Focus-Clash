//
//  GameCenterConnectedBadge.swift
//  FocusClash
//
//  Created by Foundation 44 on 03/02/26.
//

import SwiftUI

struct GameCenterConnectedBadge: View {

    @State private var show = false
    @State private var pulse = false

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark.seal.fill")
                .foregroundStyle(.green)
                .symbolEffect(.bounce, value: show)

            Text("Game Center Connected")
                .font(.footnote)
                .fontWeight(.semibold)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(
            Capsule()
                .fill(.green.opacity(0.15))
                .overlay(
                    Capsule()
                        .stroke(.green.opacity(0.4), lineWidth: 1)
                )
        )
        .scaleEffect(pulse ? 1.05 : 1)
        .opacity(show ? 1 : 0)
        .animation(.spring(response: 0.45, dampingFraction: 0.7), value: show)
        .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: pulse)
        .onAppear {
            show = true
            pulse = true
        }
    }
}

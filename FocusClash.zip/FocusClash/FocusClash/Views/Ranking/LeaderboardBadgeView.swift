//
//  LeaderboardBadgeView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

struct LeaderboardBadgeView: View {

    enum BadgeType {
        case top10
        case streak
    }

    let type: BadgeType
    @State private var animate = false

    var body: some View {
        Label(title, systemImage: icon)
            .font(.caption.bold())
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(
                Capsule()
                    .fill(color.opacity(0.15))
                    .overlay(
                        Capsule()
                            .stroke(color, lineWidth: 1.4)
                            .shadow(
                                color: color.opacity(animate ? 0.6 : 0),
                                radius: animate ? 8 : 0
                            )
                    )
            )
            .foregroundStyle(color)
            .scaleEffect(animate ? 1.05 : 0.95)
            .animation(
                .spring(response: 0.45, dampingFraction: 0.6),
                value: animate
            )
            .onAppear { animate = true }
    }

    private var title: String {
        switch type {
        case .top10: return "Top 10"
        case .streak: return "7-Day"
        }
    }

    private var icon: String {
        switch type {
        case .top10: return "crown.fill"
        case .streak: return "flame.fill"
        }
    }

    private var color: Color {
        switch type {
        case .top10: return .yellow
        case .streak: return .orange
        }
    }
}

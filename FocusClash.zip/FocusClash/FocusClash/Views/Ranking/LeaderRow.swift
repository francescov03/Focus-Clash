//
//  LeaderRow.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

struct LeaderRow: View {

    let entry: LeaderboardEntry

    var body: some View {
        HStack(spacing: 12) {

            Text("#\(entry.rank)")
                .frame(width: 40)
                .scaleEffect(entry.isCurrentUser ? 1.03 : 1)
                .animation(.spring(response: 0.3), value: entry.rank)

            avatarView

            VStack(alignment: .leading, spacing: 4) {
                Text(entry.name)
                    .font(.headline)

                HStack(spacing: 6) {

                    // 🏆 Top 10 → valido per tutti
                    if entry.rank <= 10 {
                        LeaderboardBadgeView(type: .top10)
                    }

                    // 🔥 7-Day streak → solo se ha punti reali (e non sei tu a 0)
                    if entry.points > 0 && !entry.isCurrentUser {
                        LeaderboardBadgeView(type: .streak)
                    }
                }
            }

            Spacer()

            Text("\(entry.points)")
                .bold()
        }
        .padding()
        .background(entry.isCurrentUser ? Color.blue.opacity(0.15) : .clear)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - Avatar logic
    @ViewBuilder
    private var avatarView: some View {
        if entry.isCurrentUser,
           let image = GameCenterService.shared.avatarImage {

            Image(uiImage: image)
                .resizable()
                .scaledToFill()
                .frame(width: 32, height: 32)
                .clipShape(Circle())

        } else {
            Image(systemName: "person.crop.circle")
                .font(.system(size: 28))
                .foregroundStyle(.secondary)
        }
    }
}

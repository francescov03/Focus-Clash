//
//  RankingView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

struct RankingView: View {

    let viewModel: LeaderboardViewModel
    let isAuthenticated: Bool

    @State private var showAllParticipants = false

    var body: some View {
        NavigationStack {

            if !isAuthenticated {
                // 🚫 NON CONNESSO
                VStack(spacing: 20) {
                    Image(systemName: "gamecontroller")
                        .font(.system(size: 64))
                        .foregroundStyle(.secondary)

                    Text("Connect Game Center")
                        .font(.title2)
                        .bold()

                    Text("Sign in to see the global leaderboard")
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding()
                .navigationTitle("Leaderboard")

            } else {
                // ✅ CONNESSO
                ScrollView {
                    VStack(spacing: 28) {

                        PodiumView(entries: viewModel.topLeaderboard(limit: 3))

                        VStack(alignment: .leading, spacing: 14) {
                            Text("From 4th to 10th")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)

                            ForEach(
                                viewModel.topLeaderboard(limit: 10)
                                    .filter { $0.rank >= 4 }
                            ) { entry in
                                LeaderRow(entry: entry)
                            }
                        }

                        Button {
                            showAllParticipants = true
                        } label: {
                            Label("See all participants", systemImage: "person.3.fill")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                        }
                    }
                    .padding()
                }
                .navigationTitle("Leaderboard")
                .sheet(isPresented: $showAllParticipants) {
                    ParticipantsListView(entries: viewModel.leaderboard)
                }
            }
        }
    }
}

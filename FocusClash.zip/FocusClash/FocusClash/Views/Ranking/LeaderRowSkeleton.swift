//
//  LeaderRowSkeleton.swift
//  FocusClash
//
//  Created by Foundation 44 on 03/02/26.
//

import SwiftUI

struct LeaderRowSkeleton: View {

    var body: some View {
        HStack(spacing: 12) {

            RoundedRectangle(cornerRadius: 6)
                .fill(.gray.opacity(0.3))
                .frame(width: 36, height: 18)

            Circle()
                .fill(.gray.opacity(0.3))
                .frame(width: 28, height: 28)

            VStack(alignment: .leading, spacing: 6) {
                RoundedRectangle(cornerRadius: 6)
                    .fill(.gray.opacity(0.3))
                    .frame(width: 120, height: 14)

                RoundedRectangle(cornerRadius: 6)
                    .fill(.gray.opacity(0.25))
                    .frame(width: 80, height: 12)
            }

            Spacer()

            RoundedRectangle(cornerRadius: 6)
                .fill(.gray.opacity(0.3))
                .frame(width: 40, height: 16)
        }
        .padding()
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shimmer()
    }
}

//
//  PartecipantsListView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Foundation
import SwiftUI

struct ParticipantsListView: View {

    let entries: [LeaderboardEntry]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List(entries) { entry in
                LeaderRow(entry: entry)
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
            }
            .listStyle(.plain)
            .navigationTitle("Participants")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

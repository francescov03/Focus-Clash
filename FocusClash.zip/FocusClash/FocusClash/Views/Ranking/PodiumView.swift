//
//  PodiumView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

struct PodiumView: View {

    let entries: [LeaderboardEntry]

    var body: some View {
        HStack(alignment: .bottom, spacing: 16) {
            podium(rank: 2, height: 145)
            podium(rank: 1, height: 190)
            podium(rank: 3, height: 135)
        }
        .padding(.top, 32) // spazio per i badge sopra
    }

    private func podium(rank: Int, height: CGFloat) -> some View {

        let entry = entries.first { $0.rank == rank }
        let accentColor: Color = {
            switch rank {
            case 1: return .yellow
            case 2: return .gray
            default: return .orange
            }
        }()

        return ZStack(alignment: .top) {

            // 🏆 CARD
            VStack(spacing: 10) {

                Spacer().frame(height: 16)

                if let image = entry?.avatarImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: rank == 1 ? 64 : 52, height: rank == 1 ? 64 : 52)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "person.crop.circle.fill")
                        .font(.system(size: rank == 1 ? 56 : 44))
                        .foregroundStyle(.secondary)
                }

                Text(entry?.name ?? "—")
                    .font(rank == 1 ? .headline : .subheadline)
                    .lineLimit(1)

                HStack(spacing: 6) {
                    Image(systemName: "star.fill")
                        .foregroundStyle(.yellow)
                    Text("\(entry?.points ?? 0)")
                        .bold()
                }

                Spacer()
            }
            .frame(maxWidth: .infinity)
            .frame(height: height)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(accentColor.opacity(0.35), lineWidth: rank == 1 ? 2.5 : 1.5)
            )

            // 🔢 RANK BADGE (FUORI DALLA CARD)
            Text("#\(rank)")
                .font(.caption.bold())
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(
                    Capsule()
                        .fill(accentColor.opacity(0.15))
                )
                .foregroundStyle(accentColor)
                .offset(y: -18)
        }
    }
}

//
//  MyBadgesCard.swift
//  FocusClash
//
//  Created by Foundation 44 on 03/02/26.
//

import SwiftUI

struct MyBadgesCard: View {

    let isTop10: Bool
    let hasStreak: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {

            Label("My badges", systemImage: "rosette")
                .font(.headline)

            HStack(spacing: 12) {

                if isTop10 {
                    LeaderboardBadgeView(type: .top10)
                }

                if hasStreak {
                    LeaderboardBadgeView(type: .streak)
                }

                if !isTop10 && !hasStreak {
                    Text("No badges yet")
                        .foregroundStyle(.secondary)
                        .font(.subheadline)
                }

                Spacer()
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .frame(height: 120) // ⬅️ circa il doppio delle altre card
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

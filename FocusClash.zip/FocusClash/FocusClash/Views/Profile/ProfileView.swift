//
//  ProfileView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI

struct ProfileView: View {

    let viewModel: ProfileViewModel
    let totalFocusTime: Int
    let currentRank: Int?

    @State private var showConnectedAnimation = false
    @State private var showConfetti = false
    @State private var avatarGlow = false
    
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {

                // MARK: - HEADER
                if viewModel.isAuthenticated {

                    VStack(spacing: 16) {

                        ZStack {
                            if let image = viewModel.avatarImage {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 120, height: 120)
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle()
                                            .stroke(
                                                LinearGradient(
                                                    colors: [.blue, .purple, .mint],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                ),
                                                lineWidth: avatarGlow ? 5 : 0
                                            )
                                            .blur(radius: avatarGlow ? 6 : 0)
                                    )
                                    .scaleEffect(showConnectedAnimation ? 1.05 : 0.9)
                                    .animation(
                                        .spring(response: 0.5, dampingFraction: 0.6),
                                        value: showConnectedAnimation
                                    )
                            } else {
                                Circle()
                                    .fill(.gray.opacity(0.25))
                                    .frame(width: 120, height: 120)
                                    .shimmer()
                            }
                        }

                        Text(viewModel.displayName)
                            .font(.title)
                            .bold()

                        GameCenterConnectedBadge()
                    }

                } else {
                    
                    VStack(spacing: 20) {
                        Image(systemName: "gamecontroller")
                            .font(.system(size: 64))
                            .foregroundStyle(.secondary)

                        Text("Sign in with Game Center")
                            .font(.title2)
                            .bold()

                        Button {
                            viewModel.login()
                        } label: {
                            Label(
                                "Connect Game Center",
                                systemImage: "person.crop.circle.badge.checkmark"
                            )
                            .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                Divider()

                // MARK: - STATS
                if viewModel.isAuthenticated {

                    VStack(spacing: 16) {

                        // 🏅 MY BADGES
                        MyBadgesCard(
                            isTop10: (currentRank ?? .max) <= 10,
                            hasStreak: false // per ora fake, poi lo colleghiamo al timer
                        )

                        // ⏱ TOTAL FOCUS TIME
                        ProfileStatRow(
                            title: "Total focus time",
                            value: "\(totalFocusTime) min",
                            icon: "timer"
                        )

                        // 🏆 CURRENT RANK
                        if let rank = currentRank {
                            ProfileStatRow(
                                title: "Current rank",
                                value: "#\(rank)",
                                icon: "crown"
                            )
                        }
                    }
                }

            }
            .padding()
        }
        .onChange(of: viewModel.isAuthenticated) { _, loggedIn in
            if loggedIn {
                showConnectedAnimation = true
                avatarGlow = true
                showConfetti = true

                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    showConfetti = false
                }
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active && !viewModel.isAuthenticated {
                viewModel.login()
            }
        }
        .overlay {
            if showConfetti {
                ConfettiView()
                    .ignoresSafeArea()
            }
        }
    }
}

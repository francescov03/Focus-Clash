//
//  ProfileStatRow.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Foundation
import SwiftUI

struct ProfileStatRow: View {

    let title: String
    let value: String
    let icon: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 22))
                .foregroundStyle(.blue)
                .frame(width: 32)

            Text(title)
                .font(.headline)

            Spacer()

            Text(value)
                .bold()
        }
        .padding()
        .background(.black.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

import SwiftUI

struct ContentView: View {

    // MARK: - ViewModels
    @State private var timerVM = TimerViewModel()
    @State private var leaderboardVM = LeaderboardViewModel()
    @State private var profileVM = ProfileViewModel()

    // MARK: - UI State
    @State private var selectedTab = 1
    @State private var lastAllowedTab = 1
    @State private var showDistractionAlert = false

    @Environment(\.scenePhase) private var scenePhase

    // Blocca cambio tab durante focus
    private var isTabLocked: Bool {
        timerVM.mode == .focus && timerVM.isRunning
    }

    var body: some View {

        TabView(selection: $selectedTab) {

            // 🏆 LEADERBOARD
            RankingView(
                viewModel: leaderboardVM,
                isAuthenticated: profileVM.isAuthenticated
            )
                .tabItem {
                    Label("Ranking", systemImage: "crown")
                }
                .tag(0)

            // ⏱ FOCUS
            FocusView(
                viewModel: timerVM,
                showDistractionAlert: $showDistractionAlert
            )
            .tabItem {
                Label("Home", systemImage: "house")
            }
            .tag(1)

            // 👤 PROFILE
            ProfileView(
                viewModel: profileVM,
                totalFocusTime: timerVM.completedFocusSessions * timerVM.selectedFocusMinutes,
                currentRank: leaderboardVM.currentUserRank
            )
            .tabItem {
                Label("Profile", systemImage: "person.crop.circle")
            }
            .tag(2)
        }

        // ✅ SETUP GLOBALE (UNA SOLA VOLTA)
        .onAppear {

            // 🔐 Login Game Center
            if !profileVM.isAuthenticated {
                profileVM.login()
            }

            // 🔄 Sync real points → leaderboard
            leaderboardVM.setCurrentUserPoints(timerVM.points)

            timerVM.onPointsEarned = { _ in
                leaderboardVM.setCurrentUserPoints(timerVM.points)
                HapticService.light()
            }
        }

        // 🔒 Lock tab switching durante focus
        .onChange(of: selectedTab) { _, newTab in
            if isTabLocked {
                selectedTab = lastAllowedTab
            } else {
                lastAllowedTab = newTab
            }
        }

        // 🚨 Anti-distraction
        .onChange(of: scenePhase) { _, phase in
            if phase == .background && isTabLocked {
                timerVM.resetDueToDistraction()
                showDistractionAlert = true
            }
        }
    }
}

#Preview {
    ContentView()
}

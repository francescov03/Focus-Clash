//
//  FocusView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI
import Observation

struct FocusView: View {

    @Bindable var viewModel: TimerViewModel
    @Binding var showDistractionAlert: Bool

    @State private var showInfo = false
    @State private var showResetConfirm = false
    @State private var showSetupSheet = false
    @State private var showEndSessionConfirm = false


    var body: some View {
        ZStack {
            background
                .ignoresSafeArea()
                .animation(.easeInOut(duration: 0.35), value: viewModel.isRunning)

            VStack(spacing: 18) {
                // Top spacing from notch
                Spacer().frame(height: 10)

                // Timer (NO tap-to-edit anymore)
                TimerCircleView(
                    viewModel: viewModel,
                    onReset: {
                        if viewModel.mode == .focus {
                            viewModel.pause()
                            showSetupSheet = true
                        } else {
                            viewModel.resetBreak()
                        }
                    },
                    onEndSession: {
                        showEndSessionConfirm = true
                    }
                )


                SessionInfoView(viewModel: viewModel)
                    .padding(.top, 6)

                // Main dynamic button
                ActionButtonsView(viewModel: viewModel) {
                    // If focus hasn't started yet (00:00), show setup
                    if viewModel.mode == .focus,
                       !viewModel.isRunning,
                       viewModel.focusRemaining <= 0 {
                        showSetupSheet = true
                    } else {
                        viewModel.mainButtonTapped()
                    }
                }

                Spacer(minLength: 0)
            }
            .padding(.horizontal)
            .padding(.bottom)

            // Top-right info button
            VStack {
                HStack {
                    Spacer()
                    Button {
                        showInfo = true
                    } label: {
                        Image(systemName: "info.circle")
                            .font(.title3)
                            .foregroundStyle(.white.opacity(0.9))
                            .padding(10)
                            .background(.white.opacity(0.12))
                            .clipShape(Circle())
                    }
                }
                .padding(.top, 8)
                .padding(.trailing, 12)

                Spacer()
            }
        }
        // Start Session / Setup sheet (ONLY place to edit timers)
        .sheet(isPresented: $showSetupSheet) {
            SessionSetupSheet(
                viewModel: viewModel,
                isPresented: $showSetupSheet
            ) {
                // Start focus immediately after setup
                viewModel.start()
            }
        }
        .sheet(isPresented: $showInfo) {
            InfoSheetView(viewModel: viewModel)
        }
        .alert("Focus Interrupted", isPresented: $showDistractionAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("You left the app during a focus session, so your progress was reset.")
        }
        .confirmationDialog(
            "Reset focus session?",
            isPresented: $showResetConfirm,
            titleVisibility: .visible
        ) {
            Button("Reset", role: .destructive) {
                viewModel.pause()
                showSetupSheet = true
            }
            Button("Cancel", role: .cancel) {}
        }
        
        .confirmationDialog(
            "End the session?",
            isPresented: $showEndSessionConfirm,
            titleVisibility: .visible
        ) {
            Button("End session", role: .destructive) {
                viewModel.endSession()
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This will stop the timer and reset to 00:00.")
        }

    }

    // MARK: - Background
    private var background: LinearGradient {
        if viewModel.mode == .focus && viewModel.isRunning {
            // Dark immersive focus mode
            return LinearGradient(
                colors: [
                    Color(red: 0.06, green: 0.30, blue: 0.18),
                    Color(red: 0.02, green: 0.18, blue: 0.10)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
        } else {
            // Light state (paused or break)
            return LinearGradient(
                colors: [.green, .mint],
                startPoint: .top,
                endPoint: .bottom
            )
        }
    }
}

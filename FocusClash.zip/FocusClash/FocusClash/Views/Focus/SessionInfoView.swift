//
//  SessionInfoView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI
import Observation

struct SessionInfoView: View {

    @Bindable var viewModel: TimerViewModel

    var body: some View {
        HStack {
            VStack {
                Text("FOCUS").font(.caption)
                Text(formatMinutes(viewModel.selectedFocusMinutes))
                    .font(.headline)

            }
            .frame(maxWidth: .infinity)

            Rectangle()
                .fill(.white.opacity(0.25))
                .frame(width: 1, height: 32)

            VStack {
                Text("BREAK").font(.caption)
                Text("\(viewModel.selectedBreakMinutes):00")
                    .font(.headline)
            }
            .frame(maxWidth: .infinity)
        }
        .padding()
        .background(.white.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    private func formatMinutes(_ total: Int) -> String {
        let h = total / 60
        let m = total % 60
        if h > 0 {
            return String(format: "%d:%02d:00", h, m)
        } else {
            return String(format: "%d:00", m)
        }
    }

}

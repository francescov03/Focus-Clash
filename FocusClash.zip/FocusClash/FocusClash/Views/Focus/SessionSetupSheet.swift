//
//  SessionSetupSheet.swift
//  FocusClash
//
//  Created by Foundation 44 on 03/02/26.
//

import SwiftUI
import Observation

struct SessionSetupSheet: View {
    @Bindable var viewModel: TimerViewModel
    @Binding var isPresented: Bool
    var onDoneStart: () -> Void

    // Focus as hours + minutes
    @State private var focusHours: Int
    @State private var focusMinutes: Int  // 5-min step

    // Break as minutes
    @State private var breakMinutes: Int

    init(viewModel: TimerViewModel, isPresented: Binding<Bool>, onDoneStart: @escaping () -> Void) {
        self._viewModel = Bindable(wrappedValue: viewModel)
        self._isPresented = isPresented
        self.onDoneStart = onDoneStart

        let totalFocus = viewModel.selectedFocusMinutes
        _focusHours = State(initialValue: totalFocus / 60)
        _focusMinutes = State(initialValue: totalFocus % 60)

        _breakMinutes = State(initialValue: viewModel.selectedBreakMinutes)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {

                focusWheelBlock

                pickerBlock(title: "Break", values: viewModel.breakOptions, selection: $breakMinutes)

                Spacer()
            }
            .padding(.top, 8)
            .navigationTitle("Set Timers")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { isPresented = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        let totalFocusMinutes = (focusHours * 60) + focusMinutes
                        viewModel.applySetup(
                            focusMinutes: totalFocusMinutes,
                            breakMinutes: breakMinutes
                        )
                        isPresented = false
                        onDoneStart()
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }

    private var focusWheelBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Focus")
                .font(.headline)
                .padding(.horizontal)

            HStack(spacing: 0) {
                Picker("", selection: $focusHours) {
                    ForEach(0...12, id: \.self) { Text("\($0)") }
                }
                .pickerStyle(.wheel)
                .frame(maxWidth: .infinity)
                .clipped()
                .overlay(alignment: .trailing) {
                    Text("hr")
                        .foregroundStyle(.secondary)
                        .padding(.trailing, 10)
                }

                Picker("", selection: $focusMinutes) {
                    ForEach(Array(stride(from: 0, through: 55, by: 5)), id: \.self) {
                        Text(String(format: "%02d", $0))
                    }
                }
                .pickerStyle(.wheel)
                .frame(maxWidth: .infinity)
                .clipped()
                .overlay(alignment: .trailing) {
                    Text("min")
                        .foregroundStyle(.secondary)
                        .padding(.trailing, 10)
                }
            }
            .frame(height: 160)
            .padding(.horizontal)
            .onChange(of: focusHours) {
                // Keep total within your allowed max (12h) and prevent 0:00
                if focusHours == 12 { focusMinutes = 0 }         // max 12:00
                if focusHours == 0 && focusMinutes == 0 { focusMinutes = 5 } // min 0:05
            }
            .onChange(of: focusMinutes) {
                if focusHours == 0 && focusMinutes == 0 { focusMinutes = 5 }
            }
        }
    }

    private func pickerBlock(title: String, values: [Int], selection: Binding<Int>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .padding(.horizontal)

            Picker("", selection: selection) {
                ForEach(values, id: \.self) { v in
                    Text("\(v) min").tag(v)
                }
            }
            .pickerStyle(.wheel)
            .frame(height: 140)
            .clipped()
        }
    }
}

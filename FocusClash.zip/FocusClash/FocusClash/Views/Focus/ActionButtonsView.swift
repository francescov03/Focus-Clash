//
//  ActionButtonsView.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import SwiftUI
import Observation

struct ActionButtonsView: View {

    @Bindable var viewModel: TimerViewModel
    var onMainTap: () -> Void

    var body: some View {
        Button {
            onMainTap()
        } label: {
            Label(viewModel.mainButtonTitle, systemImage: viewModel.mainButtonSystemImage)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(.blue)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 22))
        }
        .padding(.horizontal)
    }
}

import SwiftUI
import Observation

struct TimerCircleView: View {

    @Bindable var viewModel: TimerViewModel
    let onReset: () -> Void
    let onEndSession: () -> Void

    var body: some View {
        ZStack {
            // Background ring
            Circle()
                .stroke(.white.opacity(0.20), lineWidth: 18)

            // Progress ring
            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    .white.opacity(0.85),
                    style: StrokeStyle(lineWidth: 18, lineCap: .round, lineJoin: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.linear(duration: 0.15), value: progress)

            // Center content
            VStack(spacing: 12) {
                Text(viewModel.mode == .focus ? "FOCUS" : "BREAK")
                    .font(.caption)
                    .tracking(4)
                    .foregroundStyle(.white.opacity(0.85))

                Text(viewModel.formattedTime)
                    .font(.system(size: 54, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)

                Button {
                    onReset()
                } label: {
                    Label("Reset", systemImage: "arrow.counterclockwise")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.vertical, 8)
                        .padding(.horizontal, 18)
                        .background(Capsule().fill(.white.opacity(0.18)))
                }
                .buttonStyle(.plain)

                // Only visible after a session has started
                if viewModel.focusRemaining > 0 {
                    Button {
                        onEndSession()
                    } label: {
                        Label("End session", systemImage: "xmark.circle.fill")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.75))
                            .padding(.vertical, 8)
                            .padding(.horizontal, 18)
                            .background(Capsule().fill(.white.opacity(0.18)))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .frame(width: 290, height: 290)
        .contentShape(Circle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(viewModel.mode == .focus ? "Focus timer" : "Break timer")
        .accessibilityValue(viewModel.formattedTime)
    }

    private var progress: CGFloat {
        let duration = (viewModel.mode == .focus) ? viewModel.focusDuration : viewModel.breakDuration
        guard duration > 0 else { return 0 }
        let raw = (duration - viewModel.remainingTime) / duration
        return CGFloat(min(max(raw, 0), 1))
    }
}

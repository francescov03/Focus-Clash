//
//  LeaderBoardEntry.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import UIKit

struct LeaderboardEntry: Identifiable, Equatable {
    let id: UUID
    let rank: Int
    let name: String
    let points: Int
    let avatarImage: UIImage?
    let isCurrentUser: Bool
}

//
//  FocusSession.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Foundation

struct FocusSession: Equatable, Hashable {

    let focusMinutes: Int
    let shortBreakMinutes: Int
    let longBreakMinutes: Int

    static let standard = FocusSession(
        focusMinutes: 25,
        shortBreakMinutes: 5,
        longBreakMinutes: 15
    )

    // MARK: - Helpers

    var focusSeconds: Int { focusMinutes * 60 }
    var shortBreakSeconds: Int { shortBreakMinutes * 60 }
    var longBreakSeconds: Int { longBreakMinutes * 60 }
}

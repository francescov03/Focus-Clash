//
//  Player.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Foundation

struct Player: Identifiable, Equatable {

    let id: UUID
    var name: String
    var points: Int
    var avatarSymbol: String
    var isCurrentUser: Bool

    init(
        id: UUID = UUID(),
        name: String,
        points: Int,
        avatarSymbol: String = "person.circle",
        isCurrentUser: Bool = false
    ) {
        self.id = id
        self.name = name
        self.points = points
        self.avatarSymbol = avatarSymbol
        self.isCurrentUser = isCurrentUser
    }
}

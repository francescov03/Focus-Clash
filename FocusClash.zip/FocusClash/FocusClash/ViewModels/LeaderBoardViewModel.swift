//
//  LeaderBoardViewModel.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Foundation
import Observation
import SwiftUI

@Observable
final class LeaderboardViewModel {

    // MARK: - Fake leaderboard (frontend)
    private(set) var players: [Player] = [
        Player(name: "Alex", points: 18),
        Player(name: "Giulia", points: 15),
        Player(name: "Marco", points: 12),
        Player(name: "Sofia", points: 10),
        Player(name: "Luca", points: 8),
        Player(name: "YOU", points: 0, isCurrentUser: true)
    ]

    // MARK: - Sync points from TimerViewModel
    func setCurrentUserPoints(_ points: Int) {
        guard let index = players.firstIndex(where: { $0.isCurrentUser }) else { return }
        players[index].points = points
    }

    // MARK: - Computed leaderboard
    var leaderboard: [LeaderboardEntry] {
        let sorted = players.sorted {
            if $0.points != $1.points {
                return $0.points > $1.points
            }
            return $0.name < $1.name
        }

        return sorted.enumerated().map { index, player in
            LeaderboardEntry(
                id: player.id,
                rank: index + 1,
                name: player.name,
                points: player.points,
                avatarImage: nil,
                isCurrentUser: player.isCurrentUser
            )
        }
    }

    func topLeaderboard(limit: Int) -> [LeaderboardEntry] {
        Array(leaderboard.prefix(limit))
    }

    var currentUserRank: Int? {
        leaderboard.first(where: { $0.isCurrentUser })?.rank
    }
}

//
//  ProfileViewModel.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Observation
import UIKit

@Observable
final class ProfileViewModel {

    private let gameCenter = GameCenterService.shared

    // MARK: - State
    var isAuthenticated: Bool {
        gameCenter.isAuthenticated
    }

    var displayName: String {
        gameCenter.displayName ?? "Guest"
    }

    var avatarImage: UIImage? {
        gameCenter.avatarImage
    }

    // MARK: - Actions
    func login() {
        gameCenter.authenticate()
        HapticService.success()
    }
}

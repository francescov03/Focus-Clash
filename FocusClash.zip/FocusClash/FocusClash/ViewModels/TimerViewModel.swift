//
//  TimerViewModel.swift
//  FocusClash
//
//  Created by Foundation 44 on 02/02/26.
//

import Foundation
import Observation

@Observable
final class TimerViewModel {

    // MARK: - Types
    enum Mode {
        case focus
        case breakTime
    }

    private let totalPointsKey = "FocusClash.totalPoints"

    // MARK: - Options
    let focusOptions: [Int] = Array(stride(from: 5, through: 12 * 60, by: 5))

    let breakOptions: [Int] = Array(stride(from: 1, through: 60, by: 1))

    var selectedFocusMinutes: Int
    var selectedBreakMinutes: Int

    // MARK: - Configuration
    let session: FocusSession

    // MARK: - State
    var mode: Mode = .focus
    var isRunning = false

    var focusRemaining: Double
    var breakRemaining: Double

    var completedFocusSessions = 0
    var points = 0

    // MARK: - Points logic (every 5 min)
    private let pointsInterval: Double = 5 * 60
    private var awardedBlocks = 0
    private var currentFocusDuration: Double

    var onPointsEarned: ((Int) -> Void)?

    private var timer: Timer?

    // MARK: - Init
    init(session: FocusSession = .standard) {
        self.session = session
        self.points = UserDefaults.standard.integer(forKey: totalPointsKey)

        let defaultFocusMinutes = 25
        let defaultBreakMinutes = max(1, session.shortBreakSeconds / 60)

        self.selectedFocusMinutes = defaultFocusMinutes
        self.selectedBreakMinutes = defaultBreakMinutes

        // Start at 00:00 (as you requested earlier)
        self.focusRemaining = 0
        self.breakRemaining = 0
        self.currentFocusDuration = 0
    }

    // MARK: - Durations
    var focusDuration: Double { Double(selectedFocusMinutes * 60) }
    var breakDuration: Double { Double(selectedBreakMinutes * 60) }

    // MARK: - Time helpers
    var remainingTime: Double {
        get { mode == .focus ? focusRemaining : breakRemaining }
        set {
            if mode == .focus { focusRemaining = newValue }
            else { breakRemaining = newValue }
        }
    }

    var formattedTime: String {
        let t = max(0, Int(remainingTime))
        return String(format: "%02d:%02d", t / 60, t % 60)
    }

    // MARK: - One dynamic button API (for UI)
    var mainButtonTitle: String {
        switch mode {
        case .focus:
            return isRunning ? "Take a Break" : "Start Focus"
        case .breakTime:
            return isRunning ? "Back to Focus" : "Start Break"
        }
    }

    var mainButtonSystemImage: String {
        switch mode {
        case .focus:
            return isRunning ? "cup.and.saucer.fill" : "play.fill"
        case .breakTime:
            return isRunning ? "timer" : "play.fill"
        }
    }

    func mainButtonTapped() {
        switch mode {

        case .focus:
            if isRunning {
                // Take a Break -> switch AND start break immediately
                pause()
                goToBreak(resetTime: true)
                start()
            } else {
                start()
            }

        case .breakTime:
            if isRunning {
                // Back to Focus -> resume focus WITHOUT resetting remaining time
                pause()
                resumeFocusFromBreak()
                start() // auto-resume focus (optional; remove if you want it paused)
            } else {
                start()
            }

        }
    }
    private func savePoints() {
        UserDefaults.standard.set(points, forKey: totalPointsKey)
    }


    // MARK: - Controls (compatibility)
    func startPause() {
        mainButtonTapped()
    }

    func start() {
        guard timer == nil else { return }
        isRunning = true

        if mode == .focus {
            currentFocusDuration = focusRemaining
        }

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.tick()
        }
    }

    func pause() {
        isRunning = false
        timer?.invalidate()
        timer = nil
    }

    // MARK: - Editing durations
    func setFocusMinutes(_ minutes: Int) {
        guard !isRunning else { return }
        let clamped = max(5, min(12 * 60, (minutes / 5) * 5))
        selectedFocusMinutes = clamped

        if mode == .focus {
            focusRemaining = focusDuration
            currentFocusDuration = focusRemaining
            awardedBlocks = 0
        }
    }


    func setBreakMinutes(_ minutes: Int) {
        guard !isRunning else { return }
        let clamped = max(1, min(60, minutes))
        selectedBreakMinutes = clamped
        if mode == .breakTime {
            breakRemaining = breakDuration
        }
    }

    // MARK: - Setup (called by your "Start Focus" setup sheet)
    func applySetup(focusMinutes: Int, breakMinutes: Int) {
        pause()

        let f = max(5, min(12 * 60, (focusMinutes / 5) * 5))
        let b = max(1, min(60, breakMinutes))

        selectedFocusMinutes = f
        selectedBreakMinutes = b

        mode = .focus
        focusRemaining = Double(f * 60)
        breakRemaining = Double(b * 60)
        currentFocusDuration = focusRemaining
        awardedBlocks = 0
    }


    // MARK: - Manual resets
    func resetFocus() {
        pause()
        mode = .focus
        focusRemaining = focusDuration
        currentFocusDuration = focusRemaining
        awardedBlocks = 0
    }

    func resetBreak() {
        pause()
        mode = .breakTime
        breakRemaining = breakDuration
    }

    // MARK: - Tick
    private func tick() {
        guard remainingTime > 0 else {
            finishSession()
            return
        }

        remainingTime -= 1
        awardPointsIfNeeded()
    }
    
    func resumeFocusFromBreak() {
        pause()
        mode = .focus
        // IMPORTANT: do NOT touch focusRemaining
        // keep awardedBlocks/currentFocusDuration as they were from the last start() call
    }


    private func awardPointsIfNeeded() {
        guard mode == .focus else { return }

        let elapsed = currentFocusDuration - focusRemaining
        let blocks = Int(elapsed / pointsInterval)

        if blocks > awardedBlocks {
            let gained = blocks - awardedBlocks
            awardedBlocks = blocks
            points += gained
            savePoints()
            onPointsEarned?(gained)
        }
    }

    // MARK: - Transitions
    private func finishSession() {
        pause()

        if mode == .focus {
            completedFocusSessions += 1
            awardedBlocks = 0

            // Go to break, but DO NOT auto-start it
            goToBreak(resetTime: true)
            // (no start() here)
        } else {
            // Break finished -> go back to focus (paused)
            goToFocus(resetTime: true)
        }
    }
    func endSession() {
        pause()
        mode = .focus
        focusRemaining = 0
        breakRemaining = 0
        currentFocusDuration = 0
        awardedBlocks = 0
    }



    func goToBreak(resetTime: Bool = true) {
        pause()
        mode = .breakTime
        if resetTime { breakRemaining = breakDuration }
    }

    func goToFocus(resetTime: Bool = true) {
        pause()
        mode = .focus
        if resetTime {
            focusRemaining = focusDuration
            currentFocusDuration = focusRemaining
            awardedBlocks = 0
        }
    }

    // MARK: - Distraction
    func resetDueToDistraction() {
        pause()
        goToFocus(resetTime: true)
        breakRemaining = breakDuration
    }
}
